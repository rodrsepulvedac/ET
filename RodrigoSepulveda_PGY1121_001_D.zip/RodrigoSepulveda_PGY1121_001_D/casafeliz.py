import os
import numpy as np
import funciones as fn
ruts=[]
departamentos=np.empty([10,4], type(int))
compradores=np.empty((1,10), type(object))

fn.llenarmatriz(departamentos)

os.system("cls")
op=0
tipodep=0
while(op!=5):
    os.system("cls")
    print("        Casa Feliz  ")
    print("  **********************  ")
    print("1.	Comprar departamento 	")
    print("2.	Mostrar departamentos disponibles 	")
    print("3.	Ver listado de compradores 	")
    print("4.	Mostrar ganancias totales 	")
    print("5.	Salir 	")
    op=fn.validarop(op)
    if (op==1):
        fn.mostrardisponibles(departamentos)
        tipodep=fn.validardepartamento()
        revisar=fn.buscardisponible(departamentos,tipodep)
        if revisar:
            print("El departamento esta disponible")
            pagar=fn.comprardepa(departamentos,tipodep)
            print("\t Usted va a cancelar: ", pagar)
        else: 
            print("\t El asiento no esta disponible")
        os.system("pause")
    if (op==2):
        fn.mostrardisponibles(departamentos)
        os.system("pause")
    if (op==3):
        fn.comprardepa(ruts,tipodep)
        print(ruts)
        os.system("pause")
    if (op==4):
        fn.totalVenta
    if (op==5):
        print("Este programa fue hecho por Rodrigo Sepulveda el 11/7/2023")

