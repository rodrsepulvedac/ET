import os
import numpy as np
ruts=[]
def llenarmatriz(mat):
    p=1
    for i in range(10):
        for j in range(4):
            mat[i,j]=p
            p+=1
 
def validarop(op):
    while(True):
        try:
            op=int(input("   Elija opción: "))
            if(op>=1 and op<=5):
                break
            else:
                print("Debe ingresar opción entre 1 y 5")
        except ValueError:
            print("Debe ser un número entero")
    return op

def mostrardisponibles(departamento):
    os.system("cls")
    print("\t" " A""\t" " B""\t" " C""\t" " D")
    for i in range(10):
        print("\n")
        for j in range(4):
            if(j==1):
                print("\t",departamento[i,j], end=" ")
            else:
                print("\t",departamento[i,j], end=" ")
    print("\n")

def validardepartamento():
    tipodep=0
    while True:
        try: 
            tipodep=int(input("Ingrese número de departamento 1-40: "))
            if (tipodep>=1 and tipodep<=40):
                break
            else:
                print(" Error.. ingrese departamento entre  1 y 40")
        except ValueError:
            print(" Error.. ingrese departamento entre  1 y 40")
    return tipodep
    
def buscardisponible(departamento, tipodep):
    for x in range(10):
        for i in range(4):
            if (tipodep==departamento[x,i]):
                return True
    return False 

def comprardepa(departamento, tipodep):
    while(True):
        rut=(input("Ingrese su RUT: "))
        if(len(rut)>=9):
            break
        else:
            print("Ingrese un rut valido")
    ruts.append(rut)

    for x in range(10):
        for i in range(4):
            if (departamento[x,i]==tipodep):
                departamento[x,i]=0          
            if x==0 or x==4 or x==8 or x==12 or x==16 or x==20 or x==24 or x==28 or x==32 or x==36 or x==40:
                pago=3800
                return pago
            if x==1 or x==5 or x==9 or x==13 or x==17 or x==21 or x==25 or x==29 or x==33 or x==37 or x==41:
                pago=3000
                return pago
            if x==2 or x==6 or x==10 or x==14 or x==18 or x==22 or x==26 or x==30 or x==34 or x==38 or x==42:
                pago=3800
                return pago
            if x==3 or x==7 or x==11 or x==15 or x==19 or x==23 or x==27 or x==31 or x==35 or x==39 or x==43:
                pago=3500
                return pago

def totalVenta(departamentos):
    suma=0
    for x in range(10):
        for i in range(4):
            if (departamentos[x,i]==0):
                if (i==0 or i==3):
                    suma+=5000
                elif (i==1 or i==2):
                    suma+=4000
    return suma
    







		
		          


